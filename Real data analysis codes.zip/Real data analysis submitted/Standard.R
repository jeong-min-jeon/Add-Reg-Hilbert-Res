# Function to analyze the real data with CBS bandwidths and dense numerical integration grid for the additive model Jeon and Park (2020)
# The running time of this script is approximately 5 minute

source(file='C:/Users/jungm/Desktop/main_functions_standard.R')

# Obtain 2020 data
data_2020=read.csv('C:/Users/jungm/Desktop/US President 2020.csv')
Y=as.matrix(data_2020[,2:6])
Y=matrix(Y,ncol=5)
for(i in 1:nrow(Y))
{
  Y[i,3]=sum(Y[i,3:5])
}
Y=Y[,1:3]
for(i in 1:nrow(Y))
{
  Y[i,]=Y[i,]/sum(Y[i,])
}

X=as.matrix(data_2020[,c(7:9)])
W=matrix(X,ncol=3)
for(j in 1:3)
{
  W[,j]=(X[,j]-min(X[,j]))/(max(X[,j])-min(X[,j])) # re-scale the predictors in nonparametric side to [0,1]
}

n=51
T=3

# Function for computing the squared norm of y1 minus y2
# y1 and y2: compositional vectors
comp_distance=function(y1,y2)
{
  D=length(y1)
  dist=matrix(,D,D)
  for(i in 1:D)
  {
    for(j in 1:D)
    {
      dist[i,j]=(log(y1[i]/y1[j])-log(y2[i]/y2[j]))^2
    }
  }
  sum(dist)/2/D
}

d_x_1=3
# For saving results
CBS_iteration=c()
optimal_h=matrix(,nrow=n,ncol=d_x_1)
Y_hat=matrix(,nrow=n,ncol=T)
error=c()

# Get ASPE
for(k in 1:n)
{
  t1=Sys.time()
  print(k)
  W_test=matrix(W[k,],ncol=d_x_1)
  Y_test=Y[k,]
  W_training=W[-k,]
  Y_training=Y[-k,]
  CBS_result=CBS(W_test,W_training,Y_training,add=101)
  CBS_iteration[k]=CBS_result$cbs_iteration
  optimal_h[k,]=CBS_result$optimal_smoothing
  Y_hat[k,]=SBF(W_test,W_training,Y_training,optimal_h[k,],add=101)$yhat
  error[k]=comp_distance(as.vector(Y_test),as.vector(Y_hat[k,]))
  print(error[k])
  t2=Sys.time()
  print(t2-t1)
}

mean(error)
