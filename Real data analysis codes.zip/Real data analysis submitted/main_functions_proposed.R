# This R script contains functions for the CBS bandwidth selection and SBF algorithm for the partially linear additive model

# Load some necessary R and fortran files
source(file='C:/Users/jungm/Desktop/Ancillary_functions.R')
dyn.load('C:/Users/jungm/Desktop/CBS_density_simplex_Hil_cov.dll')
dyn.load('C:/Users/jungm/Desktop/SBF_density_simplex_Hil_cov.dll')

# CBS_partially_linear : function for finding the optimal CBS bandwidths via cross-validation
# Here we use the notation X for Z of the paper and use the notation Z for X of the paper
# n0: number of observations in a test set
# n: number of observations in a training set
# T: number of elements in the compositional response vector
# X_test: n0 by d numeric matrix taking values in [0,1]^d. Only used in setting the bandwidth grids
# X_training: n by d numeric matrix taking values in [0,1]^d
# Z_training: n by p numeric matrix
# Y_training: n by T numeric matrix
# add: Number of equally-spaced grid on [0,1] added to the numerical integration on [0,1]

CBS_partially_linear=function(X_test,X_training,Z_training,Y_training,add)
{
  d_x_1=ncol(X_training)
  n=nrow(X_training)
  T=ncol(Y_training)
  W_test=X_test
  W_training=X_training
  set.seed(1) # to give a consistent result
  shuffle=sample(1:n)
  Y_training=Y_training[shuffle,]
  W_training=W_training[shuffle,]
  if(length(dim(Z_training))>2)
  {
    d_z=dim(Z_training)[2]
    Z_training=Z_training[shuffle,,]
  }
  else
  {
    d_z=as.integer(1)
    Z_training=array(Z_training[shuffle,],dim=c(n,1,T))
  }
  
  # Some practical tuning
  max_sbf_iteration=as.integer(10) # maximum number of SBF iteration
  max_cbs_iteration=as.integer(10) # maximum number of CBS iteration
  epsilon=10^-4 # stopping tolerance of SBF iteration
  cv=as.integer(5) # 5-fold CV. Can be changed to other number
  smoothing_length=rep(as.integer(11),d_x_1) # corresponds to L_k; see Section S.3
  smoothing_add=rep(0.5,d_x_1) # each bandwidth grid is seq(g_{k1},g_{k1}+0.5,length=11) where g_{k1} will be determined later
  add=as.integer(add) # the numerical integration grid for int_0^1 dx_k is the union of seq(0,1,length=add) and W_test[,k]
  # Larger "add" gives more exact approximation of the integral but not necessarily gives better results
  # Larger "add" generally requires larger bandwidths and longer computing time
  
  # The below lines are fixed ones used as the arguments of a general fortran code (do not need to change them and ignore them)
  d_x_2=as.integer(0)
  d_x_3=as.integer(0)
  W_training_2=matrix(0,nrow=n,ncol=2*d_x_2)
  W_training_3=matrix(0,nrow=n,ncol=3*d_x_3)
  max_g_length=as.integer(add+n)
  g_length_2=as.integer(0)
  g_length_3=as.integer(0)
  g_2=matrix(0,g_length_2,2)
  g_3=matrix(0,g_length_3,3)
  gg_2=matrix(0,g_length_2,2*d_x_2)
  
  class=rep(as.integer(1),d_x_1)
  class_2=array(as.integer(0),dim=d_x_2)
  axis_length_2=array(0,dim=2*d_x_2)
  class_3=array(as.integer(0),dim=d_x_3)
  axis_length_3=array(0,dim=3*d_x_3)
  
  d_u=as.integer(0)
  d_v=as.integer(0)
  uv_cardinality=array(as.integer(0),dim=d_u+d_v)
  v_values=matrix(0,d_v,max_g_length)
  
  max_smoothing_length=max(smoothing_length)
  cbs_iteration=as.integer(0)
  I_or_F=as.integer(2)
  Y_domain=as.double(rep(1,T))
  
  # Finding an appropriate g_{k1}
  minimum_bandwidth_1_for_cbs=smoothing_options(W_training,epsilon,add,cv,smoothing_length,smoothing_add)[1,]
  minimum_bandwidth_1_for_sbf=smoothing_options_for_test(W_test,W_training,epsilon,add)
  optimal_smoothing=pmax(minimum_bandwidth_1_for_cbs,minimum_bandwidth_1_for_sbf)
  
  # Make {g_{k1},...,g_{kL_k}}
  smoothing_matrix=matrix(0,nrow=max(smoothing_length),ncol=d_x_1+d_x_2+d_x_3)
  for(j in 1:(d_x_1+d_x_2+d_x_3))
  {
    smoothing_matrix[1:smoothing_length[j],j]=seq(optimal_smoothing[j],optimal_smoothing[j]+smoothing_add[j],length=smoothing_length[j])
  }
  
  cv_test_size=as.integer(floor(n/cv))
  sbf_iteration=array(as.integer(0),dim=c(max_cbs_iteration,d_x_1+d_x_2+d_x_3,max_smoothing_length,cv))
  phat1=array(1,dim=c(d_x_1+d_x_2+d_x_3,max_g_length,max_cbs_iteration,d_x_1+d_x_2+d_x_3,max_smoothing_length,cv))
  
  cbs_result=.Fortran('CBS_density_simplex_Hil_cov',n=n,d_x_1=d_x_1,d_x_2=d_x_2,d_x_3=d_x_3,d_u=d_u,d_v=d_v,d_z=d_z,T=T,W_training=W_training,W_training_2=W_training_2,
                      W_training_3=W_training_3,Z_training=Z_training,Y_training=Y_training,cv=cv,cv_test_size=cv_test_size,max_g_length=max_g_length,add=add,
                      g_length_2=g_length_2,g_length_3=g_length_3,g_2=g_2,g_3=g_3,gg_2=gg_2,class=class,class_2=class_2,class_3=class_3,
                      axis_length_2=axis_length_2,axis_length_3=axis_length_3,uv_cardinality=uv_cardinality,v_values=v_values,Y_domain=Y_domain,
                      I_or_F=I_or_F,max_smoothing_length=max_smoothing_length,smoothing_length=smoothing_length,
                      smoothing_matrix=smoothing_matrix,epsilon=epsilon,max_cbs_iteration=max_cbs_iteration,
                      max_sbf_iteration=max_sbf_iteration,cbs_iteration=cbs_iteration,sbf_iteration=sbf_iteration,
                      phat1=phat1,optimal_smoothing=optimal_smoothing)
  
  return(cbs_result)
}

# SBF_partially_linear : function to perform SBF
# Z_test: n0 by p numeric matrix
# h_vector: d-vector consists of bandwidths
# add: should be the one used in CBS_partially_linear
# The rest arguments are the same as in CBS_partially_linear

SBF_partially_linear=function(X_test,X_training,Z_test,Z_training,Y_training,h_vector,add)
{
  d_x_1=ncol(X_test)
  n0=nrow(X_test)
  n=nrow(X_training)
  T=ncol(Y_training)
  W_test=X_test
  W_training=X_training
  if(length(dim(Z_training))>2)
  {
    d_z=dim(Z_training)[2]
  }
  else
  {
    d_z=as.integer(1)
    Z_test=array(Z_test,dim=c(n0,1,T))
    Z_training=array(Z_training,dim=c(n,1,T))
  }
  
  # Some practical tuning
  max_sbf_iteration=as.integer(10) # maximum number of SBF iteration
  epsilon=10^-4 # stopping tolerance of SBF iteration
  add=as.integer(add)
  
  # The below lines are fixed ones used as the arguments of a general fortran code (do not need to change them and ignore them)
  d_x_2=as.integer(0)
  d_x_3=as.integer(0)
  W_training_2=matrix(0,nrow=n,ncol=2*d_x_2)
  W_training_3=matrix(0,nrow=n,ncol=3*d_x_3)
  max_g_length=as.integer(add+max(n0,n))
  g_length_2=as.integer(0)
  g_length_3=as.integer(0)
  g_2=matrix(0,g_length_2,2)
  g_3=matrix(0,g_length_3,3)
  gg_2=matrix(0,g_length_2,2*d_x_2)
  
  class=rep(as.integer(1),d_x_1)
  class_2=array(as.integer(0),dim=d_x_2)
  axis_length_2=array(0,dim=2*d_x_2)
  class_3=array(as.integer(0),dim=d_x_3)
  axis_length_3=array(0,dim=3*d_x_3)
  
  d_u=as.integer(0)
  d_v=as.integer(0)
  uv_cardinality=array(as.integer(0),dim=d_u+d_v)
  v_values=matrix(0,d_v,max_g_length)
  
  I_or_F=as.integer(2)
  Y_domain=as.double(rep(1,T))
  
  W_test_2=matrix(0,nrow=n0,ncol=2*d_x_2)
  W_test_3=matrix(0,nrow=n0,ncol=3*d_x_3)
  
  g=integration.grid(W_test,add)
  g_length=nrow(g)
  ZY_g=integration.grid(W_training,add)
  ZY_g_length=nrow(ZY_g)
  sbf_iteration=as.integer(0)
  mhat=array(0,dim=c(n0,d_x_1+d_x_2+d_x_3,T))
  yhat=matrix(0,n0,T)
  betahat=rep(0,d_z)
  betahat_0=rep(0,T)
  smoothing_vector=as.vector(h_vector)
  
  sbf_result=.Fortran('SBF_density_simplex_Hil_cov',n0=n0,n=n,d_x_1=d_x_1,d_x_2=d_x_2,d_x_3=d_x_3,d_u=d_u,d_v=d_v,d_z=d_z,T=T,
                      W_test=W_test,W_test_2=W_test_2,W_test_3=W_test_3,Z_test=Z_test,W_training=W_training,W_training_2=W_training_2,
                      W_training_3=W_training_3,Z_training=Z_training,Y_training=Y_training,max_g_length=max_g_length,g_length=g_length,g_length_2=g_length_2,
                      g_length_3=g_length_3,g=g,g_2=g_2,g_3=g_3,gg_2=gg_2,ZY_g_length=ZY_g_length,ZY_g=ZY_g,class=class,class_2=class_2,class_3=class_3,axis_length_2=axis_length_2,
                      axis_length_3=axis_length_3,uv_cardinality=uv_cardinality,v_values=v_values,Y_domain=Y_domain,I_or_F=I_or_F,
                      smoothing_vector=smoothing_vector,epsilon=epsilon,max_sbf_iteration=max_sbf_iteration,
                      sbf_iteration=sbf_iteration,mhat=mhat,yhat=yhat,betahat=betahat,betahat_0=betahat_0)
  
  return(sbf_result)
}