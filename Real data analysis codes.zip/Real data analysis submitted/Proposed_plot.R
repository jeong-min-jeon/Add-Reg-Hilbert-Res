# Function to get plots in real data analysis for the partially linear additive model
# The notations of X and Z are opposite here
# The running time of this script is approximately 20 seconds

source(file='C:/Users/jungm/Desktop/main_functions_proposed.R')

# Obtain 2016 data
data_2016=read.csv('C:/Users/jungm/Desktop/US President 2016.csv')
compositional3=as.matrix(data_2016[,2:7])
compositional3=matrix(compositional3,ncol=6)
for(i in 1:nrow(compositional3))
{
  compositional3[i,3]=sum(compositional3[i,3:6])
}
compositional3=compositional3[,1:3]
for(i in 1:nrow(compositional3))
{
  compositional3[i,]=compositional3[i,]/sum(compositional3[i,])
}
Z1=compositional3

# Obtain 2020 data
data_2020=read.csv('C:/Users/jungm/Desktop/US President 2020.csv')
Y=as.matrix(data_2020[,2:6])
Y=matrix(Y,ncol=5)
for(i in 1:nrow(Y))
{
  Y[i,3]=sum(Y[i,3:5])
}
Y=Y[,1:3]
for(i in 1:nrow(Y))
{
  Y[i,]=Y[i,]/sum(Y[i,])
}

X=as.matrix(data_2020[,c(7:9)])
W=matrix(X,ncol=3)
for(j in 1:3)
{
  W[,j]=(X[,j]-min(X[,j]))/(max(X[,j])-min(X[,j])) # re-scale the predictors in nonparametric side to [0,1]
}

n=51
d_z=1
T=3

Z=array(Z1,dim=c(n,d_z,T))

x_grid=101
W_test=matrix(rep(seq(0,1,length=x_grid),T),ncol=T)

cbs_result=CBS_partially_linear(W_test,W,Z,Y,add=101) # Obtain CBS bandwidths from the whole dataset

smoothing_vector=cbs_result$optimal_smoothing # CBS bandwidths

Z_test=array(0,dim=c(x_grid,d_z,T))

sbf_result=SBF_partially_linear(W_test,W,Z_test,Z,Y,smoothing_vector,add=101) # Fit the whole dataset with the CBS bandwidths

m_hat=sbf_result$mhat # m_hat. Its dimension is x_grid times ncol(W_test) times T
beta_hat=sbf_result$betahat # beta_hat
beta_hat_0=sbf_result$betahat_0 # beta_hat_0

library(DirichletReg)
# Apply some function to draw plots
m1=DR_data(m_hat[,1,])
m2=DR_data(m_hat[,2,])
m3=DR_data(m_hat[,3,])

# For preliminary setting for plotting
library(pacman)
pacman::p_load(RColorBrewer)
col.pal <- RColorBrewer::brewer.pal(11, "Spectral")
new.color=colorRampPalette(col.pal)

library(plotrix)
# Just to get some extra room. Has no special meaning
par(mar=c(7,4,4,6))
testcol<-color.gradient(c(0,1),0,c(1,0),nslices=5)
col.labels<-c("Cold","Warm","Hot")
color2D.matplot(matrix(rnorm(100),nrow=10),c(1,0),0,c(0,1),main="Test color legends")
color.legend(11,6,11.8,9,col.labels,testcol,gradient="y")
par(mar=c(5,4,4,2))

# Plots in the paper
par(mfrow=c(1,1))
plot(m1,col=new.color(x_grid),dim.labels=c('','',''))
color.legend(9,6.5,9.5,9,seq(min(round(X[,1],2)),max(round(X[,1],2)),length=3),new.color(x_grid),gradient="y")
legend(x=6.6,y=10,legend='Percent of Bachelor+',bty="n")
text(8.7,5.5,labels='Democratic',col='brown')
text(8.7,5,labels='Party',col='brown')
text(0.9,5.5,labels='Republican',col='dark green')
text(0.9,5,labels='Party',col='dark green')
mtext('Remaining Party',side=1, line=2, at=4.8, col='dark blue')

plot(m2,col=new.color(x_grid),dim.labels=c('','',''))
color.legend(9,6.5,9.5,9,seq(min(X[,2]),max(X[,2]),length=3),new.color(x_grid),gradient="y")
legend(x=6.4,y=10,legend='Per Capital Income ($)',bty="n")
text(8.7,5.5,labels='Democratic',col='brown')
text(8.7,5,labels='Party',col='brown')
text(0.9,5.5,labels='Republican',col='dark green')
text(0.9,5,labels='Party',col='dark green')
mtext('Remaining Party',side=1, line=2, at=4.8, col='dark blue')

plot(m3,col=new.color(x_grid),dim.labels=c('','',''))
color.legend(9,6.5,9.5,9,seq(min(round(X[,3],2)),max(round(X[,3],2)),length=3),new.color(x_grid),gradient="y")
legend(x=7.6,y=10,legend='Median Age',bty="n")
text(8.7,5.5,labels='Democratic',col='brown')
text(8.7,5,labels='Party',col='brown')
text(0.9,5.5,labels='Republican',col='dark green')
text(0.9,5,labels='Party',col='dark green')
mtext('Remaining Party',side=1, line=2, at=4.8, col='dark blue')
