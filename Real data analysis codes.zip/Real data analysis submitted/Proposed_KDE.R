# Function to analyze the real data with optimally chosen KDE bandwidths for the partially linear additive model
# The notations of X and Z are opposite here
# The running time of this script is approximately 10 seconds

source(file='C:/Users/jungm/Desktop/main_functions_proposed.R')
source(file='C:/Users/jungm/Desktop/functions_from_cran_kedd.R')

# Obtain 2016 data
data_2016=read.csv('C:/Users/jungm/Desktop/US President 2016.csv')
compositional3=as.matrix(data_2016[,2:7])
compositional3=matrix(compositional3,ncol=6)
for(i in 1:nrow(compositional3))
{
  compositional3[i,3]=sum(compositional3[i,3:6])
}
compositional3=compositional3[,1:3]
for(i in 1:nrow(compositional3))
{
  compositional3[i,]=compositional3[i,]/sum(compositional3[i,])
}
Z1=compositional3

# Obtain 2020 data
data_2020=read.csv('C:/Users/jungm/Desktop/US President 2020.csv')
Y=as.matrix(data_2020[,2:6])
Y=matrix(Y,ncol=5)
for(i in 1:nrow(Y))
{
  Y[i,3]=sum(Y[i,3:5])
}
Y=Y[,1:3]
for(i in 1:nrow(Y))
{
  Y[i,]=Y[i,]/sum(Y[i,])
}

X=as.matrix(data_2020[,c(7:9)])
W=matrix(X,ncol=3)
for(j in 1:3)
{
  W[,j]=(X[,j]-min(X[,j]))/(max(X[,j])-min(X[,j])) # re-scale the predictors in nonparametric side to [0,1]
}

n=51
d_z=1
T=3

Z=array(Z1,dim=c(n,d_z,T))

# Function for computing the squared norm of y1 minus y2
# y1 and y2: compositional vectors
comp_distance=function(y1,y2)
{
  D=length(y1)
  dist=matrix(,D,D)
  for(i in 1:D)
  {
    for(j in 1:D)
    {
      dist[i,j]=(log(y1[i]/y1[j])-log(y2[i]/y2[j]))^2
    }
  }
  sum(dist)/2/D
}

d_x_1=3
# For saving results
CBS_iteration=c()
optimal_h=matrix(,nrow=n,ncol=d_x_1)
Y_hat=matrix(,nrow=n,ncol=T)
error=c()

# Get ASPE
for(k in 1:n)
{
  t1=Sys.time()
  print(k)
  W_test=matrix(W[k,],ncol=d_x_1)
  Z_test=array(Z[k,,],dim=c(1,d_z,T))
  Y_test=Y[k,]
  W_training=W[-k,]
  Z_training=array(Z[-k,,],dim=c(n-1,d_z,T))
  Y_training=Y[-k,]
  
  minimum_bandwidth_1_for_sbf=smoothing_options_for_test(W_test,W_training,epsilon=10^{-4},add=101)
  for(j in 1:3)
  {
    optimal_h[k,j]=h.amise(W_training[,j],lower=minimum_bandwidth_1_for_sbf[j],upper=1,kernel='biweight')$h
  }
  
  SBF_result=SBF_partially_linear(W_test,W_training,Z_test,Z_training,Y_training,optimal_h[k,],add=101)
  Y_hat[k,]=SBF_result$yhat
  error[k]=comp_distance(as.vector(Y_test),as.vector(Y_hat[k,]))
  print(error[k])
  t2=Sys.time()
  print(t2-t1)
}

mean(error)