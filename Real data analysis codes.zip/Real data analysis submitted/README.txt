Descriptions on the provided files 

(The running time of each R script is described in each R script. The R scripts can be run on R 4.2.1 under Windows 10 system)

- US President 2016.csv and US President 2020.csv : Datasets

- CBS_density_simplex_Hil_cov.dll : Fortran dll file performing the CBS bandwidth selection for the proposed method

- SBF_density_simplex_Hil_cov.dll : Fortran dll file performing the SBF algorithm for the proposed method

- Proposed_plot.R : Used to get Fig.1 and the beta hat value

- Proposed.R : Used to get the ASPE value for the proposed method with CBS bandwidths and a dense numerical integration grid

- Proposed_sparse.R : Used to get the ASPE values for the proposed method with CBS bandwidths and a sparse numerical integration grid

- Proposed_KDE.R : Used to get the ASPE value for the proposed method with optimally chosen KDE bandwidths

- main_functions_proposed.R : Contains main R functions to run the fortran dll files CBS_density_simplex_Hil_cov and SBF_density_simplex_Hil_cov. It is used in the above R scripts

- CBS_density_simplex.dll : Fortran dll file performing the CBS bandwidth selection for the method of Jeon and Park (2020)

- SBF_density_simplex.dll : Fortran dll file performing the SBF algorithm for the method of Jeon and Park (2020)

- Standard.R : Used to get the ASPE value for the method of Jeon and Park (2020)

- main_functions_standard.R : Contains main R functions to run the fortran dll files CBS_density_simplex and SBF_density_simplex. It is used in the above R script

- functions_from_cran_kedd.R : Contains ancillary R functions used in Proposed_KDE.R

- Ancillary_functions.R : Contains ancillary R functions used in main_functions_proposed.R and main_functions_standard.R