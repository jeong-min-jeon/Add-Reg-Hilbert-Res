# This R script contains ancillary functions used in constructing the numerical integration grid or in the bandwidth selection

library(fields)
library(matrixStats)

# Function to divide a dataset for CV
new_cut=function(n,cv)
{
  folds=c()
  size=floor(n/cv)
  for(k in 1:cv)
  {
    if(k<cv) folds[((k-1)*size+1):(k*size)]=k
    if(k==cv) folds[((cv-1)*size+1):n]=k
  }
  return(folds)
}

# Used to construct the numerical integration grid
integration.grid=function(W_test,add)
{
  total_grid=matrix(,add+nrow(W_test),ncol(W_test))
  if(ncol(W_test)>0)
  {
    for(j in 1:ncol(W_test))
    {
      grid_add=seq(0,1,length=add)
      total_grid[,j]=sort(c(grid_add,W_test[,j]))
    }
    return(total_grid)
  }
  else
  {
    return(matrix(0,add+nrow(W_test),ncol(W_test)))
  }
}

# Used to construct {g_{k1},...,g_{kL_k}}
smoothing_options=function(W_training,epsilon,add,cv,smoothing_length,smoothing_add)
{
  n=nrow(W_training)
  d=ncol(W_training)
  folds=new_cut(n,cv)
  distance=matrix(,nrow=cv,ncol=d)
  for(k in 1:cv)
  {
    W_training_training=matrix(W_training[-which(folds==k),],ncol=d)
    W_training_test=matrix(W_training[which(folds==k),],ncol=d)
    for(j in 1:d)
    {
      grid_add=seq(0,1,length=add)
      total_grid=c(W_training_test[,j],grid_add)
      distance[k,j]=max(rowMins(rdist(total_grid,W_training_training[,j])))
    }
  }
  smoothing_matrix=matrix(,nrow=max(smoothing_length),ncol=d)
  for(j in 1:d)
  {
    smoothing_matrix[1:smoothing_length[j],j]=seq(max(distance[,j])+epsilon,max(distance[,j])+epsilon+smoothing_add[j],length=smoothing_length[j])
  }
  return(smoothing_matrix)
}

# Used to construct {g_{k1},...,g_{kL_k}}
smoothing_options_for_test=function(W_test,W_training,epsilon,add)
{
  d=ncol(W_training)
  distance=c()
  for(j in 1:d)
  {
    grid_add=seq(0,1,length=add)
    total_grid=c(W_test[,j],grid_add)
    distance[j]=max(rowMins(rdist(total_grid,W_training[,j])))
  }
  return(distance+epsilon)
}